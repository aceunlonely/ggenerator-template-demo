﻿前端框架v1.0
有问题联系留些用

##如何使用跨域
1、其他域添加框架的Invoke.html页面
2、前端框架中dc.pageConfig.js中配置dc.out.invokeUrl
