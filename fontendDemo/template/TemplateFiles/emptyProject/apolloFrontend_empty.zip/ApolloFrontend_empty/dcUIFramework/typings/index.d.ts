/// <reference path="globals/dc.framework/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
