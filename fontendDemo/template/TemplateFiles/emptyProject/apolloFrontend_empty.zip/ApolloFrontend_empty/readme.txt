﻿# 前端框架使用说明
## 目录结构说明
|-- dcUIFramework *前端框架源码*
|-- views 存放业务系统页面
    |--dcDefault 业务系统名称
        |--resources 存放一些静态资源，比如css，js，image
        |--system 业务系统模块
|-- dc.pageConfig.js 全局配置文件

## 开发指南

## 在线帮助文档
http://192.168.10.128/dcc/