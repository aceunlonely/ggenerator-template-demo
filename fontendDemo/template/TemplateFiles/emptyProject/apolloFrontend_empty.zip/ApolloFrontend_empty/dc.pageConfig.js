﻿dc.project = dc.project || {};

//+++++++++++++++++++++++++++++++修改区域++++++++++++++++++++++++++++++++++++++++++
//后端Url，如http://192.168.10.128:8080/javaBackendDemo
dc.project.backendUrl = "todo:待修改";
//前端根地址Url, 如http://localhost:8080/ApolloFrontend
dc.project.frontendUrl = "todo:待修改";

//+++++++++++++++++++++++++++++++较固定区域++++++++++++++++++++++++++++++++++++++++++
//公共参数控件url
dc.project.commonParamUrl = dc.project.backendUrl+"/PublicCode/getList";
//于跨域调用的外层框架Invoke页面地址，如 http://192.168.10.128/apollo/invoke.html
dc.out.invokeUrl = "";
//权限数据获取地址
dc.project.permissionUrl = dc.project.backendUrl+"/Permission/getList";
//页面无权限时的提示页面
dc.project.permissionInfoUrl = dc.project.frontendUrl + "/dcUIFramework/ApolloFrontend/noPermission.html";
//是否跨域
dc.project.isCrossdomain = false;
//外部扩展
dc.out = dc.out || {};
//重写跳转
dc.out.redirect = dc.out.redirect || function (url, title) {
 location.href = url;
}
//运行模式 临时修改为开发模式
dc.project.RunMode = dc.project.Enum.dev;
//外部初始化，无需修改，项目扩展用
dc.out.init = function () {
    $(".dc-searchHidden").click(function () {
        var button = $(this);
        var dc_panel_body = button.parent().next(".dc-panel-body");
        var display = dc_panel_body.css("display");
        if (display == "none") {
            dc_panel_body.show();
            button.find(".l-btn-text").text("隐藏查询");
            dc.autoHeight();
            $(".dc-panel-head").css({
                "borderBottomStyle": "dotted",
                "borderBottomColor": "#dadada"
            });
        } else {
            dc_panel_body.hide();
            button.find(".l-btn-text").text("显示查询");
            dc.autoHeight();
            $(".dc-panel-head").css({
                "borderBottomStyle": "solid",
                "borderBottomColor": "rgb(230,231,235)"
            });
        }
    });
};

//+++++++++++++++++++++++++++++++全局枚举区域++++++++++++++++++++++++++++++++++++++++++
var Enum = Enum || {};
//Enum.YesNo = [{"value":"1","text":"是","selected":false},{"value":"2","text":"否","selected":false}];
//Enum.hbBaseNo = [{"value":"hs1","text":"hs11111111","selected":false},{"value":"hs2","text":"hs2222222","selected":false},{"value":"hs333333","text":"hs33333333","selected":false},{"value":"HS2326400888","text":"HS2326400888","selected":false}];