﻿将整个目录拷贝到前端的空项目中
cp views [targetDir]/views
