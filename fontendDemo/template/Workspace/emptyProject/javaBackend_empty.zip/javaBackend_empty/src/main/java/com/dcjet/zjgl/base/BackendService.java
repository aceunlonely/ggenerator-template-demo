package com.dcjet.zjgl.base;

import com.dcjet.apollo.framework.web.base.BaseService;

/**
 * Copyright (c) 2017, 苏州神州数码捷通科技有限公司
 * All rights reserved.
 * 
 * <h3>项目的BaseService</h3>
 * @version 1.0
 * @author Administrator
 * 
 */
public class BackendService<T> extends BaseService<T> {

}
