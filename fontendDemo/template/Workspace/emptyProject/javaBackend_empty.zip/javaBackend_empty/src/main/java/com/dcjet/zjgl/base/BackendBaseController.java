package com.dcjet.zjgl.base;

import com.dcjet.apollo.framework.web.base.BaseController;
/**
 * Copyright (c) 2017, 苏州神州数码捷通科技有限公司
 * All rights reserved.
 * 
 * <h3>项目的BaseController</h3>
 * @version 1.0
 * @author Administrator
 * 
 */
public class BackendBaseController extends BaseController  {

}
